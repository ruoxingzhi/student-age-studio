(() => {
  const button=document.createElement('button');button.className='text-button';button.textContent='工坊设置';button.id='game-location-button';
  document.querySelector('.app-header').append(button);
  document.addEventListener('click',event=>{if(event.target.closest('[data-game-location]'))button.click()});
  const dialog=document.createElement('dialog');dialog.id='game-locations';dialog.setAttribute('aria-labelledby','game-locations-title');document.body.append(dialog);
  let current,timer,opening=null,preparing=false,tab='directories',folderSaving=false;
  const folderDrafts={},folderKinds=[['portrait','人物立绘'],['background','场景背景'],['cg','CG 插画'],['audio','音乐与音效'],['social','动态配图'],['avatar','人物头像']];
  dialog.addEventListener('cancel',event=>{if(preparing)event.preventDefault()});
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(path,data){const r=await fetch('/api/'+path,{method:data?'POST':'GET',headers:{'X-Studio-Token':window.STUDIO_TOKEN,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});const v=await r.json();if(!r.ok)throw Error(v.error);return v}
  function message(text){const e=dialog.querySelector('[data-notice]');if(e)e.textContent=text}
  function setCurrent(state){current=state;window.STUDIO_MODS_STATUS=state.modsStatus;}
  function busy(value){preparing=value;dialog.querySelectorAll('button,input').forEach(e=>e.disabled=value);}
  function canSwitch(){if(window.STUDIO_HAS_UNSAVED_CHANGES?.()){message('请先关闭此窗口，保存当前模组，再切换目录。');return false}return !preparing}
  function mountFolders(body){
    const section=document.createElement('section');section.className='location-section';section.dataset.settingsGroup='folders';
    section.innerHTML='<h3>素材文件夹</h3><p class="location-help">与首次引导共用同一份设置。可选择文件夹或粘贴路径；读取时包含子文件夹，保存后后台更新素材缓存。清空路径并保存即可取消该目录。</p><div data-settings-folders>正在读取素材文件夹…</div>';
    body.append(section);
    (async()=>{try{
      let state=await api('asset-folders');if(!section.isConnected)return;
      const list=section.querySelector('[data-settings-folders]');
      list.innerHTML=folderKinds.map(([kind,label])=>`<div class="settings-asset-folder"><label class="location-path-label" for="settings-folder-${kind}">${label}</label><div class="location-path-row"><input id="settings-folder-${kind}" data-settings-folder="${kind}" value="${esc(folderDrafts[kind]??state.folders[kind]?.path??'')}" placeholder="尚未设置 · 可粘贴完整路径"><button data-settings-folder-browse="${kind}">选择文件夹</button></div><div class="location-actions"><button data-settings-folder-save="${kind}">保存目录</button><span class="location-help" data-settings-folder-status="${kind}" role="status">${esc(state.folders[kind]?.message||'')}</span></div></div>`).join('');
      list.querySelectorAll('button,input').forEach(n=>n.disabled=folderSaving);
      list.oninput=e=>{if(e.target.matches('[data-settings-folder]'))folderDrafts[e.target.dataset.settingsFolder]=e.target.value;};
      list.onclick=async e=>{
        const b=e.target.closest('button');if(!b||folderSaving)return;
        const kind=b.dataset.settingsFolderBrowse||b.dataset.settingsFolderSave,input=list.querySelector(`[data-settings-folder="${kind}"]`),status=list.querySelector(`[data-settings-folder-status="${kind}"]`);
        if(!kind)return;
        folderSaving=true;list.querySelectorAll('button,input').forEach(n=>n.disabled=true);
        try{
          if(b.hasAttribute('data-settings-folder-browse')){
            const choose=window.pywebview?.api?.choose_folder||window.STUDIO_CHOOSE_ASSET_FOLDER;
            if(!choose){input.focus();status.textContent='请粘贴文件夹的完整路径，然后保存目录。';return;}
            const path=await choose(kind);if(path&&section.isConnected){input.value=path;folderDrafts[kind]=path;status.textContent='点击“保存目录”后生效。';}return;
          }
          folderSaving=true;list.querySelectorAll('button,input').forEach(n=>n.disabled=true);status.textContent='正在保存…';
          const path=input.value;state=await api('asset-folders');state=await api('asset-folders',{kind,path,settingsRevision:state.revision});
          delete folderDrafts[kind];input.value=state.folders[kind]?.path||'';status.textContent=input.value?'已保存，后台更新素材缓存。':'已取消此素材目录。';
        }catch(error){status.textContent=error.message;}finally{folderSaving=false;dialog.querySelectorAll('[data-settings-folders] button,[data-settings-folders] input').forEach(n=>n.disabled=preparing);}
      };
    }catch(error){if(section.isConnected)section.querySelector('[data-settings-folders]').textContent=error.message;}})();
  }
  function mountProjectPreferences(body){
    const section=document.createElement('section');section.className='location-section';section.dataset.settingsGroup='directories';
    section.innerHTML='<h3>打开与读取模组</h3><p class="location-help" data-project-settings-status role="status">正在读取设置…</p><div data-project-settings></div>';body.prepend(section);
    (async()=>{try{
      let state=await api('project-preferences');if(!section.isConnected)return;
      const root=section.querySelector('[data-project-settings]'),status=section.querySelector('[data-project-settings-status]');
      const ignored=new Set(state.ignoredProjectIds),subscriptions=state.projects.filter(p=>p.readOnly);
      root.innerHTML='<label class="location-path-label" for="default-project-choice">启动时默认打开</label><select id="default-project-choice" data-default-project><option value="">沿用上次打开的模组</option>'+state.projects.filter(p=>!ignored.has(p.id)).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}${p.readOnly?'（订阅）':''}</option>`).join('')+'</select><h4>不读取这些订阅模组</h4><p class="location-help">勾选后不再加载其内容、素材或编号，清除编辑器生成的缓存。Steam 订阅与模组原文件保留；取消勾选可恢复读取。</p><input type="search" data-project-filter aria-label="搜索订阅模组" placeholder="搜索订阅模组"><div class="project-ignore-list">'+subscriptions.map(p=>`<label class="location-backup-setting" data-project-name="${esc(p.name.toLowerCase())}"><input type="checkbox" data-ignore-project="${esc(p.id)}" ${ignored.has(p.id)?'checked':''}><span>${esc(p.name)}</span></label>`).join('')+'</div><p data-ignore-count class="location-help"></p><button data-project-policy-apply class="primary">应用读取设置</button>';
      const select=root.querySelector('[data-default-project]');select.value=state.defaultProjectId;if(!select.value)select.value='';
      const checks=()=>[...root.querySelectorAll('[data-ignore-project]')],count=()=>{root.querySelector('[data-ignore-count]').textContent=`已忽略 ${checks().filter(n=>n.checked).length} / ${subscriptions.length} 个订阅模组`;};count();
      status.textContent='默认模组立即保存，下次启动自动打开；读取设置点击应用后刷新编辑器。';
      root.querySelector('[data-project-filter]').oninput=e=>{const value=e.target.value.trim().toLowerCase();root.querySelectorAll('[data-project-name]').forEach(n=>n.hidden=!n.dataset.projectName.includes(value));};
      checks().forEach(n=>n.onchange=count);
      select.onchange=async()=>{select.disabled=true;try{state=await api('project-preferences',{defaultProjectId:select.value});status.textContent='默认模组已保存，下次启动生效。';}catch(error){select.value=state.defaultProjectId;status.textContent=error.message;}finally{select.disabled=false;}};
      root.querySelector('[data-project-policy-apply]').onclick=async()=>{
        if(window.STUDIO_HAS_UNSAVED_CHANGES?.()||window.STUDIO_HAS_OPEN_DRAFT?.()){status.textContent='请先保存当前修改，再应用读取设置。未保存的草稿已保留。';return;}
        if(window.STUDIO_WORKSHOP_NAV?.busy?.()||window.STUDIO_STORY_NAV?.busy?.()){status.textContent='请等待当前操作完成后再应用。';return;}
        const chosen=checks().filter(n=>n.checked).map(n=>n.dataset.ignoreProject);
        preparing=true;dialog.querySelectorAll('button,input,select').forEach(n=>n.disabled=true);status.textContent='正在停止相关读取并清理缓存…';
        try{await api('project-preferences',{ignoredProjectIds:[...state.ignoredProjectIds.filter(id=>!subscriptions.some(p=>p.id===id)),...chosen]});location.reload();}
        catch(error){preparing=false;dialog.querySelectorAll('button,input,select').forEach(n=>n.disabled=false);status.textContent=error.message;}
      };
    }catch(error){if(section.isConnected)section.querySelector('[data-project-settings-status]').textContent=error.message;}})();
  }
  function render(){
    const s=current,mods=s.modsStatus||{},workshop=s.workshopStatus||{},gameInput=dialog.querySelector('[data-path]')?.value,modsInput=dialog.querySelector('[data-mods-path]')?.value;
    const backups=s.backups||{};
    const extras=Array.isArray(mods.extraProjects)?mods.extraProjects:[];
    const modsMessage=mods.message||(mods.exists===false?'本地模组目录尚不存在。可以新建模组，或选择已有的开发目录。':Number(mods.projectCount)>0?`已发现 ${Number(mods.projectCount)} 个本地模组。`:'当前目录中没有找到本地模组。请选择自己开发的模组所在位置。');
    dialog.innerHTML=`<div class="location-heading"><h2 id="game-locations-title">工坊设置</h2><button data-close aria-label="关闭工坊设置" title="关闭工坊设置">×</button></div><p data-notice role="status" aria-live="polite">${esc(s.message||'工坊设置保存在本机。')}</p>
      <section class="location-section"><h3>可编辑模组目录</h3><p class="location-help">可以指定任意名称的文件夹，空文件夹也可以；不存在的路径会自动创建。新建模组和创建副本保存在这里，也可以直接添加单个模组。设置会在下次启动时保留。</p><dl class="location-current"><dt>当前读写目录</dt><dd data-current-mods>${esc(mods.path||s.active?.mods||'尚未设置')}</dd></dl><p data-mods-status>${esc(modsMessage)}</p>${extras.length?`<details class="location-extras"><summary>另外添加的本地模组（${extras.length}）</summary>${extras.map(p=>`<p>${esc(typeof p==='string'?p:p.path||p.name||'')}</p>`).join('')}</details>`:''}<label class="location-path-label" for="mods-location-path">指定读写路径</label><div class="location-path-row"><input id="mods-location-path" data-mods-path placeholder="例如 D:\\作品\\学生时代模组，或粘贴已有模组的文件夹路径" value="${esc(modsInput??mods.path??s.active?.mods??'')}"><button data-mods-browse>选择文件夹</button></div><div class="location-actions"><button data-mods-manual class="primary">使用此读写目录</button></div></section>
      <section class="location-section"><h3>编辑器数据与缓存</h3><dl class="location-current"><dt>固定用户数据</dt><dd data-user-data-path>${esc(s.storage?.userData||'')}</dd></dl><p class="location-help">保存目录位置、素材文件夹、偏好与条件配置，更新或更换编辑器文件夹后仍然沿用。</p><button data-storage-open="userData">打开用户数据文件夹</button><dl class="location-current"><dt>素材缓存</dt><dd data-cache-path>${esc(s.storage?.cache||'')}</dd></dl><p class="location-help">缓存路径必须设置并保存在用户配置中，更新编辑器继续复用。新增、修改或删除素材会更新对应缓存。更改路径在下次启动生效，当前编辑可继续。</p><button data-storage-open="cache">打开缓存文件夹</button><div class="location-path-row"><input data-cache-setting aria-label="缓存文件夹路径" value="${esc(s.cacheSettings?.path||s.storage?.cache||'')}" placeholder="缓存路径必须设置"><button data-cache-setting-browse>选择文件夹</button></div><button data-cache-setting-save>保存缓存路径</button></section>
      <section class="location-section"><h3>保存偏好</h3><label class="location-backup-setting"><input type="checkbox" data-exit-save ${window.STUDIO_NAV?.saveOnExit?'checked':''}>退出编辑器时自动保存</label><p class="location-help">关闭后，退出时会询问如何处理未保存的内容。顶部“自动保存”控制离开编辑页面时的保存。</p></section><section class="location-section"><h3>模组备份</h3><dl class="location-current"><dt>备份文件夹</dt><dd data-backup-path>${esc(backups.path||'尚未设置')}</dd></dl><div class="location-path-row"><input data-backup-setting aria-label="备份文件夹" value="${esc(backups.path||'')}"><button data-backup-browse>选择文件夹</button><button data-backup-save>使用此位置</button></div><p class="location-help">更改后立即生效，旧备份保留在原文件夹。</p><label class="location-backup-setting"><input type="checkbox" data-backup-auto ${backups.autoBackup===true?'checked':''}>打开本地模组时自动备份</label><p class="location-help">默认关闭。开启后，每次打开本地模组开始编辑前会先完整备份一次；模组较大时会明显延长打开时间。左上角“手动备份”随时可用，会先保存当前修改。每份备份包含模组配置和素材，不显示在模组列表中。</p><label class="location-backup-setting"><input type="checkbox" data-backup-cleanup ${backups.autoCleanup!==false?'checked':''}>自动清理旧备份，每个模组保留最近 5 份</label><p class="location-help">自动和手动备份合计保留 5 份。取消勾选可保留全部备份；重新勾选后立即清理较旧的备份。</p><button data-backup-open>在文件管理器中查看</button></section>
      <section class="location-section"><h3>错误日志</h3><dl class="location-current"><dt>日志文件夹</dt><dd data-error-log-path>${esc(s.errorLogs?.path||'尚未设置')}</dd></dl><p class="location-help">操作发生内部异常或文件读写失败时自动生成日志，记录软件版本、出错操作和错误详情。${s.errorLogs?.autoCleanup!==false?'保留最近 20 份，超出后自动删除旧日志。':'已关闭自动清理，日志全部保留。'}当前 ${Number(s.errorLogs?.count)||0} 份。</p><label class="location-backup-setting"><input type="checkbox" data-error-cleanup ${s.errorLogs?.autoCleanup!==false?'checked':''}>自动清理旧错误日志，保留最近 20 份</label><button data-error-logs-open>打开错误日志文件夹</button></section>
      <section class="location-section"><h3>订阅模组</h3><p class="location-help">订阅模组可查看和预览；复制为本地模组后可编辑。</p><dl class="location-current"><dt>Steam 订阅目录</dt><dd data-current-workshop>${esc(workshop.path||s.active?.workshop||'选择游戏后自动查找')}</dd></dl><p data-workshop-status>${esc(workshop.message||(Number(workshop.projectCount)>0?`已发现 ${Number(workshop.projectCount)} 个订阅模组。`:'尚未找到订阅模组，请检查所选游戏和 Steam 订阅下载是否完成。'))}</p></section>
      <section class="location-section"><h3>游戏文件</h3><p class="location-help">读取原版人物、场景和音效。可自动查找 Steam 游戏库。</p><div>${(s.installations||[]).map((r,i)=>`<div class="location-installation"><strong>${esc(r.label)}</strong><p>${esc(r.game)}</p><button data-select="${i}" ${s.active?.game===r.game?'disabled':''}>${s.active?.game===r.game?'当前游戏':'使用这份游戏'}</button></div>`).join('')||'<p>尚未发现游戏。</p>'}</div><div class="location-actions"><button data-scan>自动查找游戏</button><button data-deep>深度扫描本机磁盘</button>${s.status==='running'?'<button data-stop>停止扫描</button>':''}</div><label class="location-path-label" for="game-location-path">游戏文件夹</label><div class="location-path-row"><input id="game-location-path" data-path placeholder="包含 StudentAge.exe 的文件夹" value="${esc(gameInput??s.active?.game??'')}"><button data-browse>选择文件夹</button></div><div class="location-actions"><button data-manual>使用此游戏目录</button></div></section>`;
    const sections=[...dialog.querySelectorAll('.location-section')];
    const categories=['directories','storage','preferences','storage','storage','directories','directories'];
    const body=document.createElement('div');body.className='workshop-settings-body';
    sections.forEach((section,i)=>{section.dataset.settingsGroup=categories[i];body.append(section);});
    mountFolders(body);
    window.STUDIO_DIALOGUE_KEYS?.mount(body);
    mountProjectPreferences(body);
    const appearance=document.createElement('section');appearance.className='location-section';appearance.dataset.settingsGroup='preferences';appearance.innerHTML=`<h3>界面主题</h3><label class="location-path-label" for="studio-theme-choice">外观</label><select id="studio-theme-choice"><option value="classic">经典主题 · 深绿</option><option value="glass">晴昼 · 浅蓝</option><option value="glass-dusk">暮色 · 暖紫</option><option value="glass-moon">月夜 · 深蓝</option><option value="glass-atelier">纸本 · 工作室</option><option value="glass-noir">夜幕 · 剧场（概念界面）</option></select><label class="location-path-label" for="studio-glass-material">玻璃质感</label><select id="studio-glass-material"><option value="liquid">液态玻璃</option><option value="frosted">毛玻璃 · 静谧层次</option></select><p class="location-help">毛玻璃以柔和透光、细腻边缘和层叠阴影呈现质感，不随鼠标实时渲染。三种配色均可使用；切换立即生效，下次启动保留。</p>`;body.prepend(appearance);
    // AI tools: copy-ready commands for this installation's own runtime.
    const aiTools=document.createElement('section');aiTools.className='location-section';aiTools.dataset.settingsGroup='preferences';aiTools.innerHTML='<h3>AI 工具（命令行与 MCP）</h3><p class="location-help">让 Claude、Codex 等 AI 助手直接读取和修改模组剧情。它们使用编辑器自己的保存流程：保存前自动备份、检查版本冲突，有警告时会先交给你确认。</p><div data-ai-tools><p class="location-help">正在读取…</p></div>';body.append(aiTools);
    api('ai-tools').then(t=>{const row=(label,text)=>`<label class="location-path-label">${esc(label)}</label><div class="location-path-row"><input readonly value="${esc(text)}" aria-label="${esc(label)}"><button data-ai-copy="${esc(text)}">复制</button></div>`;
     aiTools.querySelector('[data-ai-tools]').innerHTML='<div class="location-path-row"><button data-ai-prompt>复制安装提示词</button></div><p class="location-help">最省事的方法：复制后直接发给你的 AI 助手（Claude、Codex、Cursor、DeepSeek 等），它会按提示词自行完成安装和验证。'+(t.promptFile?'Windows 版的程序文件夹里也有同样内容的「AI安装MCP提示词.txt」。':'')+'</p><textarea data-ai-prompt-text readonly hidden>'+esc(t.prompt||'')+'</textarea>'+row('Claude Code（在终端运行一次）',t.claudeCode)+row('Claude 桌面版等（mcpServers 配置）',JSON.stringify(t.json))+row('Codex（~/.codex/config.toml）',t.codex.replace(/\n/g,' ⏎ '))+row('命令行示例',t.cliExample)+'<p class="location-help">Codex 配置请按 ⏎ 处换行后粘贴。更新编辑器后路径可能变化，届时请重新复制。</p>';
     const promptButton=aiTools.querySelector('[data-ai-prompt]');promptButton.onclick=async()=>{try{await navigator.clipboard.writeText(t.prompt);promptButton.textContent='已复制，发给 AI 即可';setTimeout(()=>promptButton.textContent='复制安装提示词',2500);}catch{const area=aiTools.querySelector('[data-ai-prompt-text]');area.hidden=false;area.select();message('请按 Ctrl+C（Mac 为 ⌘C）复制。');}};
     aiTools.querySelectorAll('[data-ai-copy]').forEach(b=>b.onclick=async()=>{const text=b.dataset.aiCopy.replace(/ ⏎ /g,'\n');try{await navigator.clipboard.writeText(text);b.textContent='已复制';setTimeout(()=>b.textContent='复制',1500);}catch{b.previousElementSibling.select();message('请按 Ctrl+C（Mac 为 ⌘C）复制。');}});
    }).catch(e=>{aiTools.querySelector('[data-ai-tools]').innerHTML='<p class="location-help">'+esc(e.message)+'</p>';});
    const materialChoice=appearance.querySelector('#studio-glass-material');materialChoice.value=window.STUDIO_GLASS_MATERIAL||'liquid';materialChoice.disabled=window.STUDIO_THEME==='classic'||window.STUDIO_THEME==='glass-atelier'||window.STUDIO_THEME==='glass-noir';materialChoice.onchange=async()=>{materialChoice.disabled=true;try{await window.STUDIO_SET_GLASS_MATERIAL(materialChoice.value);message('玻璃质感已保存。');}catch(e){materialChoice.value=window.STUDIO_GLASS_MATERIAL;message(e.message);}finally{materialChoice.disabled=window.STUDIO_THEME==='classic'||window.STUDIO_THEME==='glass-atelier'||window.STUDIO_THEME==='glass-noir';}};
    const themeChoice=appearance.querySelector('select');themeChoice.value=window.STUDIO_THEME||'glass';themeChoice.onchange=async()=>{themeChoice.disabled=true;try{await window.STUDIO_SET_THEME(themeChoice.value);message('主题已保存，下次启动继续使用。');}catch(e){themeChoice.value=window.STUDIO_THEME;message(e.message);}finally{themeChoice.disabled=false;materialChoice.disabled=window.STUDIO_THEME==='classic'||window.STUDIO_THEME==='glass-atelier'||window.STUDIO_THEME==='glass-noir';}};
    const idChecks=document.createElement('section');idChecks.className='location-section';idChecks.dataset.settingsGroup='preferences';idChecks.innerHTML='<h3>ID 重复检测</h3><p class="location-help">勾选要排除的模组，例如旧副本或未启用的作品。填写编号和保存时不再提示这些模组的重复编号；原版和当前模组仍会检查。</p><div data-id-check-mods>正在读取模组…</div>';body.append(idChecks);
    (async()=>{try{const [preferences,projects]=await Promise.all([api('display-settings'),api('projects')]);if(!idChecks.isConnected)return;const rows=Array.isArray(projects)?projects:projects.projects||[];let excluded=new Set(preferences.idCheckExcludedProjects||[]);const list=idChecks.querySelector('[data-id-check-mods]');list.innerHTML=rows.map(p=>`<label class="location-backup-setting"><input type="checkbox" data-id-check-exclude="${esc(p.id)}" ${excluded.has(p.id)?'checked':''}>排除 ${esc(p.name)}${p.readOnly?'（订阅）':''}</label>`).join('')||'<p>尚未发现模组。</p>';list.onchange=async e=>{const n=e.target;if(!n.matches('[data-id-check-exclude]'))return;const next=new Set(excluded);if(n.checked)next.add(n.dataset.idCheckExclude);else next.delete(n.dataset.idCheckExclude);list.querySelectorAll('input').forEach(v=>v.disabled=true);try{const saved=await api('display-settings',{idCheckExcludedProjects:[...next]});excluded=new Set(saved.idCheckExcludedProjects||[]);message('ID 检测范围已保存。');}catch(error){n.checked=excluded.has(n.dataset.idCheckExclude);message(error.message);}finally{list.querySelectorAll('input').forEach(v=>v.disabled=false);}};}catch(error){if(idChecks.isConnected)idChecks.querySelector('[data-id-check-mods]').textContent=error.message;}})();
    const contact=document.createElement('section');contact.className='location-section';contact.dataset.settingsGroup='about';contact.innerHTML='<h3>拾光工坊 · beta 公测</h3><p>反馈问题、交流模组制作，欢迎联系我们。</p><dl class="location-current"><dt>测试与讨论 QQ 群</dt><dd>1121725122</dd><dt>反馈邮箱</dt><dd>360478712scy@gmail.com</dd></dl><h3>支持拾光工坊</h3><p>如果您觉得编辑器的做的还不错，不妨支持一下！我将在未来加入更多更新！</p><a class="settings-sponsor-link" data-sponsor-link href="https://afdian.com/a/stundet-age-studio" target="_blank" rel="noopener noreferrer">前往爱发电赞助 ↗</a>';body.append(contact);contact.querySelector('[data-sponsor-link]').onclick=async e=>{e.preventDefault();try{await api('open-sponsor',{});}catch(error){message(error.message);}};
    const update=document.createElement('section');update.className='location-section';update.dataset.settingsGroup='about';body.prepend(update);
    const nav=document.createElement('nav');nav.className='workshop-settings-tabs';nav.setAttribute('aria-label','工坊设置分类');nav.innerHTML='<div class="settings-identity"><img src="/icon.png" alt=""><strong>拾光工坊</strong><span>工坊设置</span></div>'+[['directories','游戏与模组'],['folders','素材文件夹'],['storage','数据与维护'],['preferences','外观与偏好'],['about','版本与反馈']].map(([id,label])=>`<button data-settings-tab="${id}"><span class="settings-category-icon" aria-hidden="true">${({directories:"▣",folders:"▧",storage:"▤",preferences:"✓",about:"◇"})[id]}</span><span>${label}</span></button>`).join('');
    const selectTab=()=>{body.querySelectorAll('[data-settings-group]').forEach(section=>section.hidden=section.dataset.settingsGroup!==tab);nav.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.settingsTab===tab)));body.scrollTop=0;};
    nav.onclick=e=>{const b=e.target.closest('[data-settings-tab]');if(b){tab=b.dataset.settingsTab;selectTab();}};
    dialog.append(nav,body);selectTab();window.STUDIO_UPDATES?.mount(update);
    dialog.querySelector('[data-close]').onclick=()=>dialog.close();
    dialog.querySelector('[data-cache-setting-browse]').onclick=async()=>{try{let path;if(window.pywebview?.api?.choose_folder)path=await window.pywebview.api.choose_folder('cache');else if(window.STUDIO_CHOOSE_ASSET_FOLDER)path=await window.STUDIO_CHOOSE_ASSET_FOLDER('cache');else{dialog.querySelector('[data-cache-setting]').focus();message('请粘贴缓存文件夹的完整路径。');return;}if(path)dialog.querySelector('[data-cache-setting]').value=path;}catch(e){message(e.message);}};
    dialog.querySelector('[data-cache-setting-save]').onclick=async()=>{try{current.cacheSettings=await api('cache-settings',{path:dialog.querySelector('[data-cache-setting]').value});message(current.cacheSettings.restartRequired?'缓存路径已保存，下次启动生效；当前编辑与后台任务可继续。':'缓存路径已保存，后续版本继续沿用。');}catch(e){message(e.message);}};

    dialog.querySelectorAll('[data-storage-open]').forEach(b=>b.onclick=async()=>{try{await api('open-storage',{kind:b.dataset.storageOpen});}catch(e){message(e.message);}});
    // Older Mac shells only accept existing folder kinds; this opens the same folder picker.
    dialog.querySelector('[data-backup-browse]').onclick=async()=>{try{let path;if(window.pywebview?.api?.choose_folder)path=await window.pywebview.api.choose_folder('backup');else if(window.STUDIO_CHOOSE_ASSET_FOLDER)path=await window.STUDIO_CHOOSE_ASSET_FOLDER('cache');else{dialog.querySelector('[data-backup-setting]').focus();message('请粘贴备份文件夹的完整路径。');return;}if(path)dialog.querySelector('[data-backup-setting]').value=path;}catch(e){message(e.message);}};
    dialog.querySelector('[data-backup-save]').onclick=async()=>{busy(true);try{current.backups=await api('backup-settings',{path:dialog.querySelector('[data-backup-setting]').value});dialog.querySelector('[data-backup-setting]').value=current.backups.path;dialog.querySelector('[data-backup-path]').textContent=current.backups.path;message('备份位置已更改，旧备份保留在原文件夹。');}catch(e){message(e.message);}finally{busy(false);}};
    dialog.querySelector('[data-backup-auto]').onchange=async event=>{const input=event.target,value=input.checked;busy(true);try{current.backups=await api('backup-settings',{autoBackup:value});window.STUDIO_AUTO_BACKUP=current.backups.autoBackup===true;message(value?'已开启：打开本地模组时会先自动备份。':'已关闭打开时自动备份，可随时使用“手动备份”。');}catch(e){input.checked=!value;message(e.message)}finally{busy(false)}};
    dialog.querySelector('[data-backup-cleanup]').onchange=async event=>{const input=event.target,value=input.checked;busy(true);try{current.backups=await api('backup-settings',{autoCleanup:value});message(value?'已开启自动清理，每个模组保留最近 5 份备份。':'已关闭自动清理，之后的备份将全部保留。');}catch(e){input.checked=!value;message(e.message);}finally{busy(false);}};
    dialog.querySelector('[data-exit-save]').onchange=async event=>{const n=event.target;try{await STUDIO_NAV.setSaveOnExit(n.checked);}catch(e){n.checked=!n.checked;message(e.message)}};
    dialog.querySelector('[data-error-cleanup]').onchange=async event=>{const n=event.target;try{current.errorLogs=await api('error-log-settings',{autoCleanup:n.checked});}catch(e){n.checked=!n.checked;message(e.message)}};
    dialog.querySelector('[data-error-logs-open]').onclick=async()=>{try{await api('open-error-logs',{});}catch(e){message(e.message);}};
    dialog.querySelector('[data-backup-open]').onclick=async()=>{try{await api('open-backups',{});}catch(e){message(e.message);}};
    dialog.querySelector('[data-browse]').onclick=()=>browse('choose_game','[data-path]',chooseGame);
    dialog.querySelector('[data-mods-browse]').onclick=()=>browse('choose_mods','[data-mods-path]',chooseMods);
    dialog.querySelector('[data-manual]').onclick=()=>chooseGame(dialog.querySelector('[data-path]').value);
    dialog.querySelector('[data-mods-manual]').onclick=()=>chooseMods(dialog.querySelector('[data-mods-path]').value);
    dialog.querySelectorAll('[data-select]').forEach(b=>b.onclick=()=>chooseGame(s.installations[Number(b.dataset.select)].game));
    dialog.querySelector('[data-scan]').onclick=()=>scan(false);dialog.querySelector('[data-deep]').onclick=()=>scan(true);
    dialog.querySelector('[data-stop]')?.addEventListener('click',async()=>{try{await api('game-scan-cancel',{});await refresh()}catch(e){message(e.message)}});
    if(preparing)busy(true);
  }
  async function browse(method,selector,select){if(!canSwitch())return;try{if(window.pywebview?.api?.[method]){const path=await window.pywebview.api[method]();if(path){dialog.querySelector(selector).value=path;await select(path)}}else if(window.STUDIO_CHOOSE_ASSET_FOLDER){const path=await window.STUDIO_CHOOSE_ASSET_FOLDER(method==='choose_mods'?'mods':'game');if(path){dialog.querySelector(selector).value=path;await select(path)}}else{message('请将文件夹的完整路径粘贴到对应输入框，再点击下方的使用按钮。');dialog.querySelector(selector).focus()}}catch(e){message(e.message)}}
  async function refresh(){const [state,cacheSettings]=await Promise.all([api('game-locations'),api('cache-settings')]);setCurrent({...state,cacheSettings});if(dialog.open&&!preparing)render();clearTimeout(timer);if(current.status==='running')timer=setTimeout(()=>refresh().catch(e=>message(e.message)),1000)}
  async function scan(deep){try{await api('game-scan',{deep});await refresh()}catch(e){message(e.message)}}
  async function chooseGame(game){if(!canSwitch())return;if(!String(game).trim()){message('请选择或填写游戏文件夹。');return}try{busy(true);message('正在确认游戏目录…');await api('game-select',{game});await api('game-prepare',{});location.reload()}catch(e){busy(false);message(e.message)}}
  async function chooseMods(mods){if(!canSwitch())return;if(!String(mods).trim()){message('请选择或填写自己开发的模组文件夹。');return}try{busy(true);message('正在查找本地模组…');const state=await api('mods-select',{mods});if(state.selectedProjectId)localStorage.setItem('studentAgeStudio.project',state.selectedProjectId);location.reload()}catch(e){busy(false);message(e.message)}}
  function openingStatus(text,failed=false){
    if(!dialog.firstElementChild){
      dialog.innerHTML='<div class="location-heading"><h2 id="game-locations-title">工坊设置</h2><button data-close aria-label="关闭工坊设置" title="关闭工坊设置">×</button></div><p data-notice role="status" aria-live="polite"></p>';
      dialog.querySelector('[data-close]').onclick=()=>dialog.close();
    }
    let retry=dialog.querySelector('[data-settings-retry]');
    if(!retry){retry=document.createElement('button');retry.dataset.settingsRetry='';retry.textContent='重试读取';retry.onclick=()=>button.click();dialog.querySelector('[data-notice]').after(retry);}
    retry.hidden=!failed;message(text);
  }
  button.onclick=()=>{
    if(!dialog.open){openingStatus('正在读取工坊设置…');dialog.showModal();}
    if(opening)return opening;
    openingStatus('正在读取工坊设置…');
    // A late response may update the cached state, but never reopen a closed window.
    opening=refresh().catch(e=>openingStatus('读取工坊设置失败：'+e.message,true)).finally(()=>{opening=null;});
    return opening;
  };
  async function prepareAssets(){for(const [status,action] of [['resource-status','resource-refresh'],['audio-status','audio-refresh']]){const state=await api(status);if(!state.available&&state.status==='idle')await api(action,{})}}
  if(!window.STUDIO_BOOTSTRAPPING)api('game-locations').then(async s=>{setCurrent(s);if(!s.managed){return}if(!s.active){render();dialog.showModal();scan(false)}else if(s.needsPreparation){render();dialog.showModal();busy(true);message('首次启动：正在读取本机游戏配置，请稍候…');try{await api('game-prepare',{});if(window.STUDIO_HAS_UNSAVED_CHANGES?.()){busy(false);message('游戏配置已准备好。请先保存当前模组，再重新打开应用。')}else location.reload()}catch(e){busy(false);message(e.message)}}else prepareAssets().catch(()=>{})}).catch(()=>{});
})();
