# Third-party components and game resources

StudentAge Studio's original editor code is licensed under GPL-3.0-only.

- `standalone/search-pinyin.js` contains pronunciation data from pypinyin 0.55.0 under the MIT license. Its original license and copyright notice remain at the top of that file.
- `standalone/vendor-steamworks/SteamworksPy64.dll` is the upstream redistributable bridge from SteamworksPy 1.6.3 by GP Garcia, CoaguCo Industries, under the MIT license (see `standalone/vendor-steamworks/LICENSE.SteamworksPy`). Valve's `steam_api64.dll` is proprietary and is **not** shipped: at runtime the editor loads the copy from the user's own game installation or Steam client directory.
- Python packages installed through `requirements.txt` retain their own licenses. They are dependencies, not relicensed copies of this project's code.
- StudentAge game images, fonts, original tables, story data, extracted bundles and user Mods are **not included** in the public repository or code-update ZIP. Resource layout descriptions and extraction code are provided so users can work with their own local game installation.
- Optional Live2D Cubism Core binaries, proprietary SDK runtimes, native compiled helpers and bundled third-party JavaScript distributions are not included. Obtain optional SDKs from their respective vendors and follow their licenses. The editor's GPL does not grant rights to those components or to game assets.
- The name of the game identifies compatibility. This is an independent community editor.

- certifi 提供 Mozilla 根证书集合，按其 MPL-2.0 许可分发；客户端同时保留系统信任根并校验 HTTPS 证书与主机名。

## Optional Windows offline prerequisite

The Windows full package with .NET components includes Microsoft's unmodified .NET Framework 4.8 Runtime offline redistributable, `prerequisites/NDP48-x86-x64-AllOS-ENU.exe`. It is a Microsoft component, remains subject to Microsoft's license terms shown by its installer, and is not covered by this project's GPL license. The application never runs it automatically; users may run it manually when .NET Framework is missing or too old and startup fails. It does not repair damaged application files or install WebView2.

- Official download: https://go.microsoft.com/fwlink/?linkid=2088631 ([Microsoft download page](https://dotnet.microsoft.com/en-us/download/dotnet-framework/net48)).
- SHA256: `0a3a390c47e639d0f7fc65b21195fee6b7f65b066f80f70c60fab191d14b7e40`.
- Distribution guidance: [Microsoft's .NET Framework deployment guide](https://learn.microsoft.com/en-us/dotnet/framework/deployment/deployment-guide-for-developers).
- Build tooling verifies both the pinned SHA256 and a valid Microsoft Corporation Authenticode signature before bundling the cached installer. `prerequisites/SHA256SUMS.json` records the appended component files separately from the original package manifest.

## Publisher-provided editor music (2026-09-20)

The publisher supplied these recordings for the editor playlist:

- 白日 — King Gnu (added 2026-10-04)
- 水星 — Lovely Summer Chan (added 2026-10-04)
- ティファのテーマ - セブンスヘブン- (FFVII REMAKE) — SQUARE ENIX MUSIC
- 星の在り処 — ファルコム・サウンド・チーム・JDK
- Gymnopedie No. 1 — Gymnopedie
- 旅の途中で (FFVII REMAKE) — SQUARE ENIX MUSIC

These recordings and their compositions remain the property of their respective rights holders and are not covered by the source code's GPL license. The `music-*.json` files contain encoded audio assets; `editor-music-builtin.json` contains their metadata and integrity hashes.
